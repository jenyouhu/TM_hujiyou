
#include "c-abci.h"
#include <string.h>

void *ABCIApplication(Types__Request *request);
