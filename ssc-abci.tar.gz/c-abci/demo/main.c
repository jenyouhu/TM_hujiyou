
#include "dummy.h"
#include "util.h"
#include <signal.h>


void kill_signal(int sig)
{
	destroy_dummy();
	server_stop();
	printf("Exit From C-ABCI Server\n");
	exit( 1 );
}

int main(int argc, char *argv[])
{
	char port[16] = {};
	char ipaddr[256] = {};

	signal(SIGTERM, kill_signal);   /* ����killall�ź� */

	if ( argc < 3 )
	{
		strcpy(ipaddr, "127.0.0.1");
		strcpy(port, "46658");
	}
	else
	{
		strcpy(ipaddr, argv[1]);
		strcpy(port, argv[2]);
	}
	printf("IP Addr=[%s] Port is=[%s].................\n",ipaddr,port );

	init_dummy();
        printf(" init_dummy OK...................... \n"); 

	server_init(ipaddr, port);
        printf(" server_init OK......................\n");

	Application app = ABCIApplication;

        printf(" server_start begin...............\n" ) ;
	server_start(app);
        printf(" server_start END................ \n");

	server_stop();
}

